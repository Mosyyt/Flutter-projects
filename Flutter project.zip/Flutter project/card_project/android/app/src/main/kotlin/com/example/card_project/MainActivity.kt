package com.example.card_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
