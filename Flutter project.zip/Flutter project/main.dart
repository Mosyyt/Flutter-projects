import 'package:flutter/material.dart';

void main() {
  runApp(myApp());
}

class myApp extends StatelessWidget {
  const myApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color.fromARGB(255, 190, 192, 190),
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 115, 115, 115),
          title: Text("Quiz"),
        ),
        body: body(),
      ),
    );
  }
}

class body extends StatefulWidget {
  body({super.key});

  @override
  State<body> createState() => _bodyState();
}

int ques_num = 0;

List q = [
  "Solar system has eight planets?",
  "Are cats a carnivores?",
  "Is China an african country?",
  "Is earth Flat?"
];
List ans = [true, true, false, false, true];
List images = [
  "images/image-1.jpg",
  "images/image-2.jpg",
  "images/image-3.jpg",
  "images/image-4.jpg",
  "images/image-5.jpg",
];

class _bodyState extends State<body> {
  @override
  List<Widget> answersResult = [
    Padding(
      padding: EdgeInsets.all(7),
      child: Icon(
        Icons.thumb_up,
        color: Colors.green,
      ),
    ),
    Padding(
      padding: EdgeInsets.all(7),
      child: Icon(
        Icons.thumb_down,
        color: Colors.red,
      ),
    ),
  ];
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          flex: 5,
          child: Column(
            children: [
              Row(
                children: answersResult,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Image.asset(images[ques_num]),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  q[ques_num],
                  style: TextStyle(
                    fontSize: 30,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          flex: 1,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
              ),
              onPressed: () {
                setState(() {
                  ques_num++;
                });
              },
              child: Text(
                "True",
                style: TextStyle(
                  fontSize: 60,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  ques_num++;
                });
              },
              child: Text(
                "False",
                style: TextStyle(
                  fontSize: 60,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color.fromARGB(255, 229, 13, 13),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
